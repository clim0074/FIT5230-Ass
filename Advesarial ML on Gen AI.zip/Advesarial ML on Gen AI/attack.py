import torch
import torch.nn.functional as F
from torchvision import transforms
from PIL import Image

def apply_sticker(image, sticker, location=(0, 0)):
    image.paste(sticker, location, sticker)  # Apply sticker to the image
    return image

def perform_attack(model, image, stickers):
    transform = transforms.Compose([
        transforms.Resize((160, 160)),
        transforms.ToTensor(),
    ])

    image_tensor = transform(image).unsqueeze(0)

    original_prediction = model(image_tensor)
    print(f"Original prediction: {torch.argmax(original_prediction)}")

    for sticker in stickers:
        # Apply sticker and perturb the image
        perturbed_image = apply_sticker(image.copy(), sticker, location=(10, 10))
        perturbed_tensor = transform(perturbed_image).unsqueeze(0)

        # Predict with the sticker applied
        perturbed_prediction = model(perturbed_tensor)
        print(f"Prediction after attack: {torch.argmax(perturbed_prediction)}")

        if torch.argmax(perturbed_prediction) != torch.argmax(original_prediction):
            print("Adversarial sticker attack successful!")
            return perturbed_image

    return image  # Return original if attack failed
