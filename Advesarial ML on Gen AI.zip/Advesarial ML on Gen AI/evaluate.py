import numpy as np
import torch
from skimage.metrics import structural_similarity as ssim

from attack import apply_sticker

import torch
from torchvision import transforms

def analyze_confidence(model, image, stickers):
    # Define the transform to convert the image to a tensor and resize it
    transform = transforms.Compose([
        transforms.Resize((160, 160)),  # Adjust this size based on your model's input
        transforms.ToTensor(),           # Convert image to PyTorch tensor
    ])

    # Transform the image before passing it to the model
    image_tensor = transform(image).unsqueeze(0)  # Add batch dimension

    original_output = model(image_tensor)
    original_confidence = torch.nn.functional.softmax(original_output, dim=1)
    original_label = torch.argmax(original_output).item()

    confidence_data = {'facial_hair': [], 'monkey': []}

    # Analyze confidence with facial hair stickers
    for sticker in stickers['beard']:
        perturbed_image = apply_sticker(image.copy(), sticker)
        perturbed_image_tensor = transform(perturbed_image).unsqueeze(0)  # Transform perturbed image
        perturbed_output = model(perturbed_image_tensor)
        perturbed_confidence = torch.nn.functional.softmax(perturbed_output, dim=1)
        confidence_data['facial_hair'].append((original_label, perturbed_confidence.detach().numpy()))  # Store as numpy for easy handling

    # Analyze confidence with monkey stickers
    for sticker in stickers['monkey']:
        perturbed_image = apply_sticker(image.copy(), sticker)
        perturbed_image_tensor = transform(perturbed_image).unsqueeze(0)  # Transform perturbed image
        perturbed_output = model(perturbed_image_tensor)
        perturbed_confidence = torch.nn.functional.softmax(perturbed_output, dim=1)
        confidence_data['monkey'].append((original_label, perturbed_confidence.detach().numpy()))  # Store as numpy for easy handling

    return confidence_data


def assess_visual_quality(original_image, perturbed_image):
    original = np.array(original_image)
    perturbed = np.array(perturbed_image)
    return ssim(original, perturbed, multichannel=True)
