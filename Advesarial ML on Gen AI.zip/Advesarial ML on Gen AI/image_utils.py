from PIL import Image

def resize_image(image, size=(160, 160)):
    return image.resize(size)

def crop_face(image, bounding_box):
    return image.crop(bounding_box)
