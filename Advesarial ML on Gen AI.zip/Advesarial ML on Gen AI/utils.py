from PIL import Image
import os

def load_images(folder_path):
    images = []
    for filename in os.listdir(folder_path):
        if filename.endswith(".jpg") or filename.endswith(".png"):
            img = Image.open(os.path.join(folder_path, filename))
            images.append(img)
    return images

def load_stickers(folder_path, target_size=(80, 80)):
    stickers = []
    for filename in os.listdir(folder_path):
        if filename.endswith(".png"):
            sticker = Image.open(os.path.join(folder_path, filename))
            
            # Check if the sticker has an alpha channel
            if sticker.mode != 'RGBA':
                sticker = sticker.convert('RGBA')

            # Resize the sticker to the target size using LANCZOS filter
            sticker = sticker.resize(target_size, Image.LANCZOS)
            stickers.append(sticker)
    return stickers



def load_true_labels(data_dir):
    true_labels = []
    for filename in os.listdir(data_dir):
        if filename.endswith('.jpg'):  # Adjust this if you're using a different image format
            # Extract the name from the filename
            label = filename.split('_')[0]  # This will get the name (e.g., 'Angelina')
            true_labels.append(label)  # Add the name as the label
    return true_labels

