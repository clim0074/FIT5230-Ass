import torch
import matplotlib.pyplot as plt
from torchvision import transforms
from attack import perform_attack
from evaluate import analyze_confidence, assess_visual_quality
from utils import load_images, load_stickers, load_true_labels
from model_loader import load_model
import os

os.environ['KMP_DUPLICATE_LIB_OK'] = 'True'

# Define the image transformations
transform = transforms.Compose([
    transforms.Resize((160, 160)),  # Resize to the input size of your model
    transforms.ToTensor(),  # Convert to tensor
])

def predict_label(model, image):
    # Apply the transformations to the image
    image_tensor = transform(image)  # Transform the PIL image to a tensor
    image_tensor = image_tensor.unsqueeze(0)  # Add batch dimension

    with torch.no_grad():
        output = model(image_tensor)  # Predict with the model
        _, predicted = torch.max(output, 1)  # Get the predicted class
    return predicted.item()  # Return as a regular integer

if __name__ == "__main__":
    # Load real people images and facial hair stickers
    images = load_images('data/')
    stickers = load_stickers('stickers/')
    print(stickers)
    # Load true labels based on filenames
    true_labels = load_true_labels('data/')  # Load true labels from filenames

    # Load a pre-trained face recognition model
    model = load_model('models/facenet.pth')

    successful_attacks = 0
    total_images = len(images)

    # Perform adversarial sticker attack
    for idx, image in enumerate(images):
        original_label = predict_label(model, image)  # Predict original label
        perturbed_image = perform_attack(model, image, stickers)  # Perform attack
        perturbed_label = predict_label(model, perturbed_image)  # Predict perturbed label
        
        # Display the original and perturbed images
        plt.subplot(1, 2, 1)
        plt.imshow(image)
        plt.title(f"Original Image\nTrue Label: {true_labels[idx]}, Predicted: {original_label}")
        plt.axis('off')

        plt.subplot(1, 2, 2)
        plt.imshow(perturbed_image)
        plt.title(f"Perturbed Image\nPredicted: {perturbed_label}")
        plt.axis('off')

        plt.show()

        # Analyze confidence scores
        confidence_results = analyze_confidence(model, image, stickers)
        print("Confidence analysis results:", confidence_results)

        # Assess visual quality
        visual_quality = assess_visual_quality(image, perturbed_image)
        print(f"Visual Quality (SSIM): {visual_quality}")
        print("Attack performed on the image!")

        # Check if the attack was successful
        if perturbed_label != original_label:
            successful_attacks += 1  # Increment if the attack was successful

    # Calculate success rate
    success_rate = successful_attacks / total_images * 100 if total_images > 0 else 0
    print(f"Success Rate of the Attack: {success_rate:.2f}%")


